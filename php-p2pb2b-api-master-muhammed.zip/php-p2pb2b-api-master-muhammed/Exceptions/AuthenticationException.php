<?php

declare(strict_types=1);

namespace Exceptions;

use Exception;

class AuthenticationException extends Exception
{
}