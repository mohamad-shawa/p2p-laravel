<?php

declare(strict_types=1);

namespace Exceptions;

use LogicException;

class ApiConstructorException extends LogicException
{
}