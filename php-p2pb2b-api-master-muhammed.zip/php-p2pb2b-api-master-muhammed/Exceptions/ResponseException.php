<?php

declare(strict_types=1);

namespace Exceptions;

use Exception;

class ResponseException extends Exception
{
}